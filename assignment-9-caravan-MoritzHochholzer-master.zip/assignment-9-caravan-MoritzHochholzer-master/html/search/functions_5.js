var searchData=
[
  ['new_5fcamel',['new_camel',['../pack__animal_8cpp.html#ac2819706d25693a334ad8a36e2f827d3',1,'new_camel(const char *name, int max_speed):&#160;pack_animal.cpp'],['../pack__animal_8h.html#ac2819706d25693a334ad8a36e2f827d3',1,'new_camel(const char *name, int max_speed):&#160;pack_animal.cpp']]],
  ['new_5fcaravan',['new_caravan',['../caravan_8cpp.html#ae0a7d2eff9414efa086ad500e11ce07f',1,'new_caravan():&#160;caravan.cpp'],['../caravan_8h.html#ae0a7d2eff9414efa086ad500e11ce07f',1,'new_caravan():&#160;caravan.cpp']]],
  ['new_5fhorse',['new_horse',['../pack__animal_8cpp.html#a41871d96d14d73fb7405b11384e7a030',1,'new_horse(const char *name, int max_speed):&#160;pack_animal.cpp'],['../pack__animal_8h.html#a41871d96d14d73fb7405b11384e7a030',1,'new_horse(const char *name, int max_speed):&#160;pack_animal.cpp']]]
];
