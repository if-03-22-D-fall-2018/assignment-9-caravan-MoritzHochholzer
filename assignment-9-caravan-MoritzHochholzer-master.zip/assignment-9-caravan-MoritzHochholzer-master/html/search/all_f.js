var searchData=
[
  ['version',['version',['../shortcut_8cpp.html#aae0723227a447e55f27ee7d2cbfc81cc',1,'version():&#160;shortcut.cpp'],['../shortcut_8h.html#aae0723227a447e55f27ee7d2cbfc81cc',1,'version():&#160;shortcut.cpp']]]
];
